## Module <ohrms_core>

#### 01.02.2019
#### Version 12.0.2.0.0
##### ADD
- Added Hrms link.

#### 22.10.2018
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Open HRMS Core Module
