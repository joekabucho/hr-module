## Module <hr_multi_company>

#### 30.03.2018
#### Version 11.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
